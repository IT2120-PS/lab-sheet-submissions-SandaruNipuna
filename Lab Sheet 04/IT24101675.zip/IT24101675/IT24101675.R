setwd("C:\\Users\\it24101675\\Desktop\\IT24101675")
getwd()